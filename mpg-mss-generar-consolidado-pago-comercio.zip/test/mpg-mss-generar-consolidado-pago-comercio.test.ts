// import * as cdk from 'aws-cdk-lib';
// import { Template } from 'aws-cdk-lib/assertions';
// import * as MpgMssGenerarConsolidadoPagoComercio from '../lib/mpg-mss-generar-consolidado-pago-comercio-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/mpg-mss-generar-consolidado-pago-comercio-stack.ts
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new MpgMssGenerarConsolidadoPagoComercio.MpgMssGenerarConsolidadoPagoComercioStack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
