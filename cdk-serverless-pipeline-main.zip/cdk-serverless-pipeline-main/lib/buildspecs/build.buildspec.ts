export const CompileBuildSpecJson = {
    "version": "0.2",
    "env": {
        "variables": {
            "STACKNAME_TARGET": "",
            "REGION_TARGET": "",
            "ACCOUNT_TARGET": "",
            "BRANCH": ""
        }
    },
    "phases": {
        "install": {
            "commands": [
                "npm install -g aws-cdk",
                "npm install -g cdk-assets"]
        },
        "pre_build": {
            "commands": [
                `if [ -f "package.json" ]; then
                    ACTUAL_NAME=$(jq -r '.name' "package.json")
                    if [ "$ACTUAL_NAME" == "$STACKNAME_TARGET" ]; then
                        echo "Stackname: $STACKNAME_TARGET"
                    else
                        echo "ERROR: El campo 'name' en package.json ($ACTUAL_NAME) no coincide con el stackname: $STACKNAME_TARGET"
                        exit 1
                    fi
                else
                    echo "ERROR: No se encontró el archivo package.json en el directorio actual."
                    exit 1
                fi`,
                "set -e",
                "npm install",
                "echo \"Assuming deployment role to use cdk diff and cdk bootstrap...\"",
                `export ASSUME_ROLE_CREDENTIALS=$(aws sts assume-role --region $REGION_TARGET --role-arn "arn:aws:iam::$ACCOUNT_TARGET:role/devops-deployment-role" --role-session-name temp-role | jq -r ".Credentials")`,
                "export AWS_ACCESS_KEY_ID=$(echo $ASSUME_ROLE_CREDENTIALS | jq -r \".AccessKeyId\")",
                "export AWS_SECRET_ACCESS_KEY=$(echo $ASSUME_ROLE_CREDENTIALS | jq -r \".SecretAccessKey\")",
                "export AWS_SESSION_TOKEN=$(echo $ASSUME_ROLE_CREDENTIALS | jq -r \".SessionToken\")",
                "export AWS_DEFAULT_REGION=$REGION_TARGET"
            ]
        },
        "build": {
            "commands": [
                `CDK_BOOTSTRAP_STACK=$(aws cloudformation list-stacks --query 'StackSummaries[?(StackName==\`CDKToolkit\` && (StackStatus==\`CREATE_COMPLETE\` || StackStatus==\`UPDATE_COMPLETE\` ))].StackId' --output text)
                echo $CDK_BOOTSTRAP_STACK
                if [ -z "$CDK_BOOTSTRAP_STACK" ] ; then
                  echo "Bootstrapping CDK..."
                  cdk bootstrap aws://$ACCOUNT_TARGET/$REGION_TARGET
                else echo "Already bootstrapped" ;
                fi`,
                "echo Synthesizing CDK...",
                "npx cdk synth -c stage=\"$BRANCH\" -c region=$REGION_TARGET",
                `cdk-assets -p "cdk.out/$STACKNAME_TARGET-$BRANCH".assets.json publish`,
                "echo \"Printing assets.json file\"",
                `cat "cdk.out/$STACKNAME_TARGET-$BRANCH.assets.json"`,
            ]
        }
    },
    "artifacts": {
        "base-directory": "cdk.out",
        "files": "**/*"
    }
}