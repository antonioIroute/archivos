export interface ConfigPipelinesStack {
    identifier : string;
    repositoryName : string;
    projectStackName?:string;
    veracodeProjectName? : string;
    prismaProjectName? : string;
    team:DevTeam;
    reportSendJira:string;
    accountDev?:string;
    accountRel?:string;
    accountProd?:string;
    regionDev?:string;
    regionRel?:string;
    regionProd?:string;
    pipelineRole?:string;
    deployRoleDev?:string;
    deployRoleRel?:string;
    deployRoleProd?:string;
    arnBucketArtifacts?:string;
    arnKeyArtifacts?:string;
    veracodeAppName:string;
    experimental?:boolean;
    props?:Record<string,any>
}

export const veracodeDefaultProjectName="bb-devops-security-veracode";
export const prismaDefaultProjectName="bb-devops-security-prismacloud";
export const qaDefaultProjectName: string = 'dvops-common-qualitysonar-serverless';
export const unitTestDefaultProjectName: string = 'bb-devops-unit-test-typescript';
export const perfomanceDefaultProjectName: string = 'bb-devops-stress-test-typescript';
export const integrationTestDefaultProjectName: string = 'bb-devops-integration-test-typescript';

export const accountDevRel="851725196162";
export const regionDevRel="us-east-1";

export const buildDefaultProjectName="bb-devops-build-serverless";

export const pipelineRoleDefault: string = 'arn:aws:iam::732624442759:role/devops-serverless-executor-pipeline-rolcActnon-prod';
export const eventRoleDefault: string = 'arn:aws:iam::732624442759:role/devops-events-rules-pipeline-role';
export const s3ArnArtifactCenterDefault="arn:aws:s3:::bb-devops-artifact-center-cross-account";
export const kmsArtifactCenterDefault="arn:aws:kms:us-east-1:732624442759:key/dfb6c88b-62da-48d9-a67e-498b4eec262b";


export enum DevTeam {
    CANALES_FISICOS_CAJEROS = "ATM",
    ACTIVOS_PERSONA = "ACPS",
    CANALES_DIGITALES_24ONLINE = "BVIR",
    FABRICA_SOFTWARE = "FAB",
    CANALES_DIGITALES_24MOVIL = "BMK",
    CANALES_DIGITALES_EMPRESA = "SAT",
    INTEGRACION_ECUAGIROS = "INGR",
    MEDIOS_PAGOS_PERSONAS = "MPPS",
    SERVICIOS_ADMINISTRATIVOS_EMPRESARIALES = "SAE",
    DIGITALIZACXION_RESGO_CONTROL = "BDR",
    PASIVOS_PERSONAS = "PAPS",
    CORE_ACTIVOS = "CACT",
    RECAUDACIONES = "REC",
    CORE_PASIVOS = "CPAS",
    CONTACTABILIDAD_CANALES_ALTERNOS = "CCAL",
    CORRESPONSAL_NO_BANCARIO = "CNB",
    DATA_WAREHOUSE = "DWH",
    DEVSECOPS = "DEVOPS",
    MEDIOS_PAGO = "MPG"
}

