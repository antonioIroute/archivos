import { ConfigPipelinesStack, DevTeam } from "./defaults.interfaces";

export const ConfigDevopsTestStack:ConfigPipelinesStack = {
    identifier: "devops-srvless-experimental-test",
    repositoryName: "devops-srvless-experimental-test",
    team: DevTeam.MEDIOS_PAGOS_PERSONAS,
    reportSendJira:"false",
    veracodeAppName:"OTD - MEDIOS DE PAGO",
    accountDev:"851725196162",
    regionDev:"us-east-1",
    accountRel:"851725196162",
    regionRel:"us-east-1",
    accountProd:"851725196162",
    regionProd:"us-east-1",
}