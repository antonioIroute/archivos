# Welcome to your CDK Pipeline

The project allows deploying a few components one aws, such as: code commit, code build, and code deploy. It focuses on lifecycle to application building with CDK on typescript.

Before deploying this application, it is essential to understand the following aspects.
* It creates three pipelines.
* Each pipeline has cross-account deploy.
* Each pipeline are triggered from branches like develop, release, and master.
* Each pipeline deploys in a different AWS account.
* It is essential to make a trust relationship between each AWS account.

## First step: Make a bootstrap of the CDK pipeline project.
Make sure you have CLI credentials with enough permission for each account where you have deployed.
The proyect allow you to have an account called "aws-devops" and  account to deploy called "aws-dev" "aws-pre" "aws-pro" 

### Bootstrap and trust relationship between each account

Imagine the following scenario where we have an account "devops-account", and another account to deploy the workload that represents my environments. "dev-account" "pre-account" "pro-account"

"devops-account" is where we are going to deploy the pipelines.

"dev-account" is where we are going to deploy the workload: it represents the develop branch.
"pre-account" is where we are going to deploy the workload: it represents the release branch.
"pro-account" is where we are going to deploy the workload: it represents the master branch.

{devops-account}
{dev-account}
{pre-account}
{pro-account}

##Bootstrap the pipeline into devops-account

cdk bootstrap  {devops-account}/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess'--profile bb-devops

##Bootstrap to the target account: in our case, it should be three account dev-pre-pro

cdk bootstrap {dev-account}/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess' --trust {devops-account}  --trust-for-lookup {devops-account}

cdk bootstrap {pre-account}/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess' --trust {devops-account}  --trust-for-lookup {devops-account} 

cdk bootstrap {pro-account}/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess' --trust {devops-account}  --trust-for-lookup {devops-account}

## Second step


##Bootstrap the pipeline into devops-account

cdk bootstrap  732624442759/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess' --profile bb-devops --bootstrap-kms-key-id arn:aws:kms:us-east-1:732624442759:key/ad5179a5-3b1c-4990-b1d1-88b8abf3570c --qualifier hnb659fds


##Bootstrap to the target account: in our case, it should be three account dev-pre-pro

cdk bootstrap 549254110166/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess' --trust 732624442759 --trust-for-lookup 732624442759 --profile bb-procesamientotd-dev 

cdk bootstrap 256094301028/us-east-1 --cloudformation-execution-policies 'arn:aws:iam::aws:policy/AdministratorAccess' --trust 732624442759 --trust-for-lookup 732624442759 --profile bb-sandbox-dev --qualifier hnb659fds
