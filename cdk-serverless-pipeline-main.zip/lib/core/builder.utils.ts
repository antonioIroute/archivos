import { Construct } from "constructs";
import { CdkPipelinesStack } from "../stacks/pipeline-base-serverless.stack";
import { ConfigPipelinesStack } from "./defaults.interfaces";
import * as cdk from 'aws-cdk-lib';
import {execSync} from "child_process"

export const builderStack = async (app: Construct, config: ConfigPipelinesStack, props?: cdk.StackProps) => {

    const response = execSync('curl "https://devops.api.cuentafuturo.com/v1/devops-core/cdk-config"', { encoding: 'utf-8' });

    const teamConfig = JSON.parse(response);
    const githubteams = teamConfig.data[0][`${config.team?.toLocaleLowerCase()}`];
    if (!githubteams) {
        throw new Error("No existe team ${config.team?.toLocaleLowerCase()}");
    }
    
    config.props = githubteams

    const pipelineStack = new CdkPipelinesStack(app, config, props);
    new cdk.CfnOutput(pipelineStack, `out-${config.identifier}-pipe`, {
        value: pipelineStack.stackName,
    });
};