import { ConfigPipelinesStack, DevTeam } from "./defaults.interfaces";

export const ConfigDevopsTestStack:ConfigPipelinesStack = {
    identifier: "mpg-mss-generar-consolidado-pago-comercio",
    repositoryName: "mpg-mss-generar-consolidado-pago-comercio",
    team: DevTeam.MEDIOS_PAGO,
    reportSendJira:"false",
    veracodeAppName:"MEDIOS DE PAGO",
    accountDev:"981631255281",
    regionDev:"us-east-1",
    accountRel:"981631255281",
    regionRel:"us-east-1",
    //accountProd:"851725196162",
    //regionProd:"us-east-1",
}