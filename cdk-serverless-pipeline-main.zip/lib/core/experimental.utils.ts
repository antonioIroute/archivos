import {ConfigPipelinesStack} from "./defaults.interfaces";

const features = [
    "GITHUB ENTERPRISE",
    "SECURITY STAGE - VERACODE",
    "SECURITY STAGE - PRISMA CLOUD"
]

export const experimentalFeature = (config: ConfigPipelinesStack) => {

    if (!config.experimental) return

    experimentalFeaturePrint(config.identifier, config.experimental)
    experimentalFeatureValidation(config)

}

const experimentalFeaturePrint = (stackname: string, experimental: boolean) => {
    if (!experimental) return
    console.log(`************************   INFO  ${stackname}   ***********************`);
    console.log("***********************************************************");
    console.log("***********************************************************");
    console.log("EXPERIMENTAL FEATURES ENABLED");
    features.forEach((feature) => {
        console.log(`- ${feature}`);
    })
    console.log("***********************************************************");
    console.log("***********************************************************");

}


const experimentalFeatureValidation = (config: ConfigPipelinesStack) => {

    if (!config.experimental) return

    if (!config.veracodeAppName) {
        throw new Error(`${config.identifier}: veracodeAppName is required for experimental features`)
    }
    
    const propsTeams = config.props ?? {}
    if (!propsTeams["veracode-secret"]) {
        throw new Error(`${config.identifier}: veracode-secret is required for experimental features, contact with DevSecOps team`)
    }
    if (!propsTeams.org || !propsTeams.connection ) {
        throw new Error(`${config.identifier}: Org and Connection Github doesnt exit, contact DevSecOps`)
    }
}