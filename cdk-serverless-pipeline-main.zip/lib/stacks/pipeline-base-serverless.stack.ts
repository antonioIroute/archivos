import * as cdk from 'aws-cdk-lib';
import * as codepipeline from 'aws-cdk-lib/aws-codepipeline';
import * as codecommit from 'aws-cdk-lib/aws-codecommit';
import * as codebuild from 'aws-cdk-lib/aws-codebuild';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as kms from 'aws-cdk-lib/aws-kms';
import { CompileBuildSpecJson as buildJson } from '../buildspecs/build.buildspec';
import * as codepipeline_actions from 'aws-cdk-lib/aws-codepipeline-actions';
import { Construct } from 'constructs';
import {
    buildDefaultProjectName,
    ConfigPipelinesStack,
    eventRoleDefault,
    integrationTestDefaultProjectName, kmsArtifactCenterDefault,
    perfomanceDefaultProjectName,
    pipelineRoleDefault,
    prismaDefaultProjectName,
    qaDefaultProjectName,
    s3ArnArtifactCenterDefault,
    unitTestDefaultProjectName,
    veracodeDefaultProjectName,
} from '../core/defaults.interfaces';

import { experimentalFeature } from '../core/experimental.utils';


export class CdkPipelinesStack extends cdk.Stack {

    //config: ConfigPipelinesStack;
    ownerRepository:string;
    connectionArn:string;
    repositoryName: string;
    identifier: string;

    /*****Stage Release******/
    veracodeAppName: string;
    veracodeProjectName: string;
    veracodeSecret:string;
    prismaProjectName: string;
    qaProjectName: string;
    unitTestProjectName: string;
    perfomanceTestProjectName: string;
    integrationTestProjectName: string;


    pipelineRole: iam.IRole;
    eventRole: iam.IRole;
    bucketArtifacts: s3.IBucket;

    outputSourceDev: codepipeline.Artifact;
    outputBuildDev: codepipeline.Artifact;
    outputSourceRel: codepipeline.Artifact;
    outputBuildRel: codepipeline.Artifact;
    outputSourceProd: codepipeline.Artifact;
    outputBuildProd: codepipeline.Artifact;

    devName: string;
    mails: string;
    groupName: string;
    sendJira: string;
    pathPerfomance: string;
    pathIntegration: string;    
    team:string;

    accountRel:any;
    accountDev:any;
    accountProd:any;
    deployRoleDev:any;
    deployRoleRel:any;
    deployRoleProd: any;
    regionProd:any;
    regionRel:any;
    regionDev:any;

    
    get repositoryId() {
        return `${this.identifier}Repository`;
    }

    get pipelineId() {
        return `${this.identifier}Pipeline`;
    }

    get qaProjectId() {
        return `${this.identifier}QAProject`;
    }

    get veracodeProjectId(): string {
        return `${this.identifier}VeracodeProject`;
    }

    get prismaCloudProjectId(): string {
        return `${this.identifier}PrismaProject`;
    }

    get unitTestProjectId() {
        return `${this.identifier}UnitTestProject`;
    }

    get integrationTestProjectId() {
        return `${this.identifier}IntegrationTestProject`;
    }

    get perfomanceTestProjectId() {
        return `${this.identifier}PerfomanceTestProject`;
    }

    get buildProjectId() {
        return `${this.identifier}SynthCdkProject`;
    }

    get buildProjectName() {
        return `${this.identifier}-build`;
    }

    get approveActionName() {
        return `Approve`;
    }

    constructor(scope: Construct, config: ConfigPipelinesStack, props?: cdk.StackProps) {
        super(scope, `cdk-${config.identifier}-stack`, props);

        const kmsKey = kms.Key.fromKeyArn(this, 'BucketKmsKeyId', config.arnKeyArtifacts ?? kmsArtifactCenterDefault);

        this.bucketArtifacts = s3.Bucket.fromBucketAttributes(this, 'DevopsArtifactsBucket', {
            bucketArn: config.arnBucketArtifacts ?? s3ArnArtifactCenterDefault,
            encryptionKey: kmsKey
        });

        /* ROLES */
        this.pipelineRole = iam.Role.fromRoleArn(this, `${this.identifier}-pipeline-role`, config.pipelineRole ?? pipelineRoleDefault, { mutable: false });
        this.eventRole = iam.Role.fromRoleArn(this, `${this.identifier}-eventsrules-role`, eventRoleDefault, { mutable: false });

        /* ARTIFACT */
        this.outputSourceDev = new codepipeline.Artifact();
        this.outputBuildDev = new codepipeline.Artifact();
        this.outputSourceRel = new codepipeline.Artifact();
        this.outputBuildRel = new codepipeline.Artifact();
        this.outputSourceProd = new codepipeline.Artifact();
        this.outputBuildProd = new codepipeline.Artifact();


        /* VARIABLES REPOSITORY-DOCKER-S3*/
        this.repositoryName = config.repositoryName;
        this.connectionArn = config.props?.["connection"];
        this.ownerRepository = config.props?.["org"];

        /*****Stage Release******/
        this.veracodeProjectName = veracodeDefaultProjectName;
        this.prismaProjectName = prismaDefaultProjectName;
        this.qaProjectName = qaDefaultProjectName;
        this.unitTestProjectName = unitTestDefaultProjectName;
        this.perfomanceTestProjectName = perfomanceDefaultProjectName;
        this.integrationTestProjectName = integrationTestDefaultProjectName;
        this.pathPerfomance = "Rendimiento/" + config.team + "/" + this.repositoryName;
        this.pathIntegration = "Integracion/" + config.team + "/" + this.repositoryName;
        
        /* VARIABLES */
        this.identifier = config.identifier;
        this.mails = config.props?.emails;
        this.groupName = config.props?.name;
        this.sendJira = config.reportSendJira;
        this.team = config.team;
        this.veracodeSecret = config.props?.["veracode-secret"];
        this.veracodeAppName = config.veracodeAppName;

        /* ACCOUNTS */
        this.accountRel = config.accountRel;
        this.accountDev = config.accountDev;
        this.accountProd = config.accountProd;
        this.regionProd = config.regionProd;
        this.regionDev = config.regionDev;
        this.regionRel = config.regionRel;

        this.createPipelines();
    }

    async createPipelines() {
        this.createPipelineDevelop();
        this.createPipelineRelease();
        this.createPipelineProd();
    }

     createPipelineDevelop(){
        const environment = "dev";
        const pipeline = this.initPipeline();

        //build stage
        const buildProject = codebuild.Project.fromProjectName(this, `${this.buildProjectId}`, buildDefaultProjectName);
        const buildAction = this.createBuildAction(buildProject, this.accountDev, this.regionDev);
        pipeline.addStage({
            stageName: 'Build-Serverless',
            actions: [buildAction],
        });

        const actionDeployCrossAccountEast = this.createDeployAction( this.accountDev, this.regionDev, environment);

        pipeline.addStage({
            stageName: 'Deploy-Serverless',
            actions: [actionDeployCrossAccountEast]
        });
        new cdk.CfnOutput(this,`pipeline-${this.identifier}-${environment}-out-1`,{
            value: pipeline.pipelineArn
        })
    }

    createPipelineRelease() {

        const enviroment = "rel";
        
        const pipeline = this.initPipeline(enviroment);

        //Unit Test
        const unitTestProject = codebuild.Project.fromProjectName(this, this.unitTestProjectId, this.unitTestProjectName)
        const unitTestAction = new codepipeline_actions.CodeBuildAction({
            actionName: "UnitTest_TypeScript_Micro",
            project: unitTestProject,
            input: this.outputSourceRel,
            environmentVariables: {
                GROUP_CODE: { value: this.team, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                GROUP_TEAM: {value: this.groupName, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT},
                ENVIAR_JIRA: { value: this.sendJira, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                NOTIFICATION_MAIL_TO: {value: this.mails, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT}
            },
            role: this.pipelineRole
        });

        
        //QA stage
        const qaProjec = codebuild.Project.fromProjectName(this, this.qaProjectId, this.qaProjectName);
        const qaAction = new codepipeline_actions.CodeBuildAction({
            actionName: "Sonar_TypeScript_Micro",
            project: qaProjec,
            input: this.outputSourceRel,
            environmentVariables: {
                GROUP_CODE: { value: this.team, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                GROUP_TEAM: {value: this.groupName, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT},
                ENVIAR_JIRA: { value: this.sendJira, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                NOTIFICATION_MAIL_TO: {value: this.mails, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT}
            },
            role: this.pipelineRole
        });
        pipeline.addStage({
            stageName: 'Quality-Micro',
            actions: [unitTestAction, qaAction],
        });

        //build stage
        const buildProject = codebuild.Project.fromProjectName(this, `${this.buildProjectId}-${enviroment}`, buildDefaultProjectName);

        const buildAction = this.createBuildAction(buildProject, this.accountRel, this.regionRel, enviroment);
        pipeline.addStage({
            stageName: 'Build-Serverless',
            actions: [buildAction],
        });

        const veracodeSecretName = this.veracodeSecret;
        const veracodeProjec = codebuild.Project.fromProjectName(this, this.veracodeProjectId, this.veracodeProjectName);
        const veracodeAction = new codepipeline_actions.CodeBuildAction({
            actionName: "Veracode_Micro",
            project: veracodeProjec,
            input: this.getBuildArtifact(enviroment),
            environmentVariables: {
                APPNAME: { value: this.veracodeAppName, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                AUTH_ID: {
                    value: `${veracodeSecretName}:id`,
                    type: codebuild.BuildEnvironmentVariableType.SECRETS_MANAGER
                },
                AUTH_SECRET: {
                    value: `${veracodeSecretName}:secret`,
                    type: codebuild.BuildEnvironmentVariableType.SECRETS_MANAGER
                },
                TYPE: { value: "SERVERLESS", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                GROUP_CODE: { value: this.team, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                ENVIAR_JIRA: { value: this.sendJira, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                COMMIT_MESSAGE: { value: "#{SourceVariables.CommitMessage}", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                COMMIT_AUTHOR: { value: "#{SourceVariables.AuthorId}", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                COMMIT_ID: { value: "#{SourceVariables.CommitId}", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT }

            },
            role: this.pipelineRole
        });

        const prismaProjec = codebuild.Project.fromProjectName(this, this.prismaCloudProjectId, this.prismaProjectName);
        const prismaAction = new codepipeline_actions.CodeBuildAction({
            actionName: "Prisma_Micro",
            project: prismaProjec,
            input: this.getBuildArtifact(enviroment),
            environmentVariables: {
                TYPE: { value: "SERVERLESS", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                GROUP_CODE: { value: this.team, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                ENVIAR_JIRA: { value: this.sendJira, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                COMMIT_MESSAGE: { value: "#{SourceVariables.CommitMessage}", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                COMMIT_AUTHOR: { value: "#{SourceVariables.AuthorId}", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                COMMIT_ID: { value: "#{SourceVariables.CommitId}", type: codebuild.BuildEnvironmentVariableType.PLAINTEXT }
            },
            role: this.pipelineRole
        });
         pipeline.addStage({
             stageName: 'Security-Micro',
             actions: [veracodeAction, prismaAction],
         });

        const actionDeployCrossAccountEast = this.createDeployAction(this.accountRel,this.regionRel, enviroment);

        pipeline.addStage({
            stageName: 'Deploy-Serverless',
            actions: [actionDeployCrossAccountEast]
        });

        //Integration
        const integrationTestProject = codebuild.Project.fromProjectName(this, this.integrationTestProjectId, this.integrationTestProjectName)
        const integrationTestAction = new codepipeline_actions.CodeBuildAction({
            actionName: "Integration_Micro",
            project: integrationTestProject,
            input: this.outputSourceRel,
            runOrder: 1,
            environmentVariables: {
                GROUP_CODE: { value: this.team, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                GROUP_TEAM: {value: this.groupName, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT},
                ENVIAR_JIRA: { value: this.sendJira, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                INTEGRATION_WORKDIR: { value: this.pathIntegration, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                NOTIFICATION_MAIL_TO: {value: this.mails, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT}
            },
            role: this.pipelineRole
        });
        //Perfomance
        const perfomanceTestProject = codebuild.Project.fromProjectName(this, this.perfomanceTestProjectId, this.perfomanceTestProjectName)
        const perfomanceTestAction = new codepipeline_actions.CodeBuildAction({
            actionName: "Stress_Load_Micro",
            project: perfomanceTestProject,
            input: this.outputSourceRel,
            runOrder: 2,
            environmentVariables: {
                GROUP_CODE: { value: this.team, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                GROUP_TEAM: {value: this.groupName, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT},
                ENVIAR_JIRA: { value: this.sendJira, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                NOTIFICATION_MAIL_TO: {value: this.mails, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT},
                PERFOMANCE_WORKDIR: { value: this.pathPerfomance, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT }
            },
            role: this.pipelineRole
        });
        pipeline.addStage({
            stageName: 'Perfomance-Micro',
            actions: [integrationTestAction, perfomanceTestAction],
        });


        new cdk.CfnOutput(this,`pipeline-${this.identifier}-${enviroment}-out-2`,{
            value: pipeline.pipelineArn
        })

    }

     createPipelineProd() {

        const environment = "prod";
        if (!this.accountProd || !this.regionProd) {
            console.warn(`${this.identifier}: Account or Region ${this.getBranchByEnv(environment)} not defined`);
            return;
        }

        //init pipeline
        const pipeline = this.initPipeline(environment);

        const buildProject = codebuild.Project.fromProjectName(this, `${this.buildProjectId}-${environment}`, buildDefaultProjectName);
        const buildAction = this.createBuildAction(buildProject, this.accountProd, this.regionProd, environment);
        pipeline.addStage({
            stageName: 'Build-Serverless',
            actions: [buildAction],
        });


        //PROD

        // Create a manual approval action with email notification
        const manualApprovalAction = new codepipeline_actions.ManualApprovalAction({
            actionName: this.approveActionName,
            role: this.pipelineRole
            //notificationTopic: approvalTopic // Notify the SNS topic for approval notifications
        });

        // Create the manual approval stage and add the manual approval action
        pipeline.addStage({
            stageName: 'Manual_Approval',
            actions: [manualApprovalAction]
        });



        const actionDeployCrossAccountEast = this.createDeployAction(this.accountProd,
            this.regionProd, environment);

        pipeline.addStage({
            stageName: 'Deploy-Serverless',
            actions: [actionDeployCrossAccountEast]
        });
        new cdk.CfnOutput(this,`pipeline-${this.identifier}-${environment}-out-3`,{
            value: pipeline.pipelineArn
        })

    }

    getSourceArtifact(environment: string): codepipeline.Artifact {
        const artifacts: Record<string, codepipeline.Artifact> = {
            "dev": this.outputSourceDev,
            "rel": this.outputSourceRel,
            "prod": this.outputSourceProd
        }
        return artifacts[environment.toLocaleLowerCase()] ?? this.outputSourceDev;
    }

    getBuildArtifact(environment: string): codepipeline.Artifact {

        const artifacts: Record<string, codepipeline.Artifact> = {
            "dev": this.outputBuildDev,
            "rel": this.outputBuildRel,
            "prod": this.outputBuildProd
        }
        return artifacts[environment.toLocaleLowerCase()] ?? this.outputBuildDev;
    }

    initPipeline(environment: string = "Dev"): codepipeline.Pipeline {
        const repo = this.getCodeCommitRepository(environment);
        // Define your pipeline tags
        const pipeline = new codepipeline.Pipeline(this, `${this.pipelineId}-${environment.toLocaleLowerCase()}`,
            {
                pipelineType: codepipeline.PipelineType.V2,
                pipelineName: `pipe-${this.identifier.toLocaleLowerCase()}-${environment.toLocaleLowerCase()}`,
                role: this.pipelineRole,
                crossAccountKeys: true,
                artifactBucket: this.bucketArtifacts
            });


        cdk.Tags.of(pipeline).add('tipo', 'serverless');

        const sourceAction = new codepipeline_actions.CodeStarConnectionsSourceAction({
            actionName: "Source_Github_Serverless",
            connectionArn: this.connectionArn,
            owner: this.ownerRepository,
            repo: this.repositoryName || this.identifier,
            branch: this.getBranchByEnv(environment.toLocaleLowerCase()),
            output: this.getSourceArtifact(environment),
            role: this.pipelineRole,
            variablesNamespace: "SourceVariables",
            codeBuildCloneOutput: environment.toLocaleLowerCase() == "rel",
        });

        pipeline.addStage({
            stageName: 'Github-Source',
            actions: [sourceAction],
        });
        return pipeline;
    }

    createBuildProyect(): codebuild.IProject {

        return new codebuild.Project(this, this.buildProjectId, {
            projectName: `${this.buildProjectName}`,
            environment: {
                buildImage: codebuild.LinuxBuildImage.AMAZON_LINUX_2_5,
                privileged: true,
            },
            buildSpec: codebuild.BuildSpec.fromObjectToYaml(buildJson),
            role: this.pipelineRole
        });
    }

    createBuildAction(buildProject: codebuild.IProject, account: string, region: string, environment: string = "dev"): codepipeline_actions.CodeBuildAction {
        return new codepipeline_actions.CodeBuildAction({
            actionName: `Build_Project_${environment.toUpperCase()}`,
            project: buildProject,
            input: this.getSourceArtifact(environment),
            outputs: [this.getBuildArtifact(environment)],
            environmentVariables: {
                STACKNAME_TARGET: { value: `${this.identifier}`, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                ACCOUNT_TARGET: { value: account, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                REGION_TARGET: { value: region, type: codebuild.BuildEnvironmentVariableType.PLAINTEXT },
                BRANCH: { value: this.getStacknameByEnv(environment), type: codebuild.BuildEnvironmentVariableType.PLAINTEXT }
            },
            role: this.pipelineRole
        });
    }

    createDeployAction(account: string, region: string, environment: string = "dev"): codepipeline_actions.CloudFormationCreateUpdateStackAction {


        const arnDeployRole = this.getDeployRole(environment);
        const arnDeployRoleAction = this.getActionDeployRole(environment);

        const deployRole = iam.Role.fromRoleArn(this, `${this.identifier}-${environment}-deploy-role`, arnDeployRole, { mutable: false });
        const deployActionRole = iam.Role.fromRoleArn(this, `${this.identifier}-${environment}-action-role`, arnDeployRoleAction, { mutable: false });
        return new codepipeline_actions.CloudFormationCreateUpdateStackAction({
            account: account,
            templatePath: this.getBuildArtifact(environment).atPath(`${this.identifier}-${this.getStacknameByEnv(environment)}.template.json`),
            adminPermissions: true,
            stackName: `${this.identifier}-${this.getStacknameByEnv(environment)}`,
            actionName: `Cross_Account_East_${environment.toUpperCase()}`,
            region: region,
            role: deployActionRole,
            deploymentRole: deployRole,
        });


    }

    getCodeCommitRepository(environment: string = "Dev"): codecommit.Repository {
        return codecommit.Repository.fromRepositoryName(this, this.repositoryId + "-" + environment,
            this.repositoryName) as codecommit.Repository;
    }

    getBranchByEnv(environment: string): string {
        const branches: Record<string, string> = {
            "dev": "develop",
            "rel": "release",
            "prod": "main"
        }
        return branches[environment.toLocaleLowerCase()] ?? "develop";
    }

    getStacknameByEnv(environment: string): string {
        const branches: Record<string, string> = {
            "dev": "dev",
            "rel": "pre",
            "prod": "pro"
        }
        return branches[environment.toLocaleLowerCase()] ?? "dev";
    }

    getDeployRole(environment: string): string {

        const branches: Record<string, string> = {
            "dev": this.deployRoleDev ?? `arn:aws:iam::${this.accountDev}:role/devops-deployment-role`,
            "rel": this.deployRoleRel ?? `arn:aws:iam::${this.accountRel}:role/devops-deployment-role`,
            "prod": this.deployRoleProd ?? `arn:aws:iam::${this.accountProd ?? this.accountDev}:role/devops-deployment-role`
        }
        return branches[environment.toLocaleLowerCase()] ?? branches["dev"];

    }
    getActionDeployRole(environment: string): string {

        const branches: Record<string, string> = {
            "dev": this.deployRoleDev ?? `arn:aws:iam::${this.accountDev}:role/devops-switch-role`,
            "rel": this.deployRoleRel ?? `arn:aws:iam::${this.accountDev}:role/devops-switch-role`,
            "prod": this.deployRoleProd ?? `arn:aws:iam::${this.accountProd ?? this.accountDev}:role/devops-switch-role`
        }
        return branches[environment.toLocaleLowerCase()] ?? branches["dev"];

    }


}